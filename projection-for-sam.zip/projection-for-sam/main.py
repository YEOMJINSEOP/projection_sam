import os
import glob
import pickle

import numpy as np
from PIL import Image
from utils.iostream import *


def _mappcd2img(seq, pts, im_size, color_lorr='left'):
    P, Tr = P_dict[seq + "_" + color_lorr], Tr_dict[seq]
    pts_homo = np.column_stack((pts, np.array([1] * pts.shape[0], dtype=pts.dtype)))
    Tr_homo = np.row_stack((Tr, np.array([0, 0, 0, 1], dtype=Tr.dtype)))
    pixel_coord = np.matmul(Tr_homo, pts_homo.T)
    pixel_coord = np.matmul(P, pixel_coord).T
    pixel_coord = pixel_coord / (pixel_coord[:, 2].reshape(-1, 1))
    pixel_coord = pixel_coord[:, :2]

    x_on_image = (pixel_coord[:, 0] >= 0) & (pixel_coord[:, 0] <= (im_size[0] - 1))
    y_on_image = (pixel_coord[:, 1] >= 0) & (pixel_coord[:, 1] <= (im_size[1] - 1))
    mask = x_on_image & y_on_image & (pts[:, 0] > 0)  # only front points

    return pixel_coord, mask


root = 'C:\\posco\\lidar-seg\\dataset\\KITTI-sample\\sequences\\14'

id = '000514'  # 'png' 'bin
seqs = ['14']

# load intrinsic
P_dict = {}
Tr_dict = {}
for seq in seqs:
    with open(os.path.join(root, 'calib.txt'), 'r') as calib:
        P = []
        for idx in range(4):
            line = calib.readline().rstrip('\n')[4:]
            data = line.split(" ")
            P.append(np.array(data, dtype=np.float32).reshape(3, -1))
        P_dict[seq + "_left"] = P[2]
        P_dict[seq + "_right"] = P[3]
        line = calib.readline().rstrip('\n')[4:]
        data = line.split(" ")
        Tr_dict[seq] = np.array(data, dtype=np.float32).reshape((3, -1))

# load images
img1 = os.path.join(root, 'image_2', id + '.png')
img2 = os.path.join(root, 'image_3', id + '.png')
img1 = Image.open(img1).convert('RGB')
img2 = Image.open(img2).convert('RGB')

# load pcd and label
pts = np.fromfile(os.path.join(root, 'velodyne', id + '.bin'), dtype=np.float32).reshape((-1,4))
# labels = np.fromfile(os.path.join(root, 'labels', id + '.label'), dtype=np.uint32).reshape([-1, 1])

save_obj('in.obj', pts)
# point to img projection
pcoord1, mask1 = _mappcd2img(seqs[0], pts[:,:3], img1.size, "left")
# pcoord2, mask2 = _mappcd2img(seqs[0], pts[:,:3], img1.size, "right")

# pcoord1[:, 0] = pcoord1[:, 0] / (img1.size[0] - 1) * 2 - 1.0
# pcoord1[:, 1] = pcoord1[:, 1] / (img1.size[1] - 1) * 2 - 1.0
# pcoord2[:, 0] = pcoord2[:, 0] / (img2.size[0] - 1) * 2 - 1.0
# pcoord2[:, 1] = pcoord2[:, 1] / (img2.size[1] - 1) * 2 - 1.0

valid_pts = pts[mask1]
# valid_labels = labels[mask1]

save_obj('valid.obj', valid_pts)